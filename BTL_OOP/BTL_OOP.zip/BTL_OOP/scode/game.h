#include<iostream>
#include"MENU.h"
#include"mainfunc.h"
//
enum state{MENU,INGAME,HELP};
void GAME();


