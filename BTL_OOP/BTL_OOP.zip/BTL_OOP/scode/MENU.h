#include<iostream>
#include"Do hoa.h"
#include<string.h>
	
	
void ve_bir1(int x,int y);
void ve_bir2(int x,int y);
void ve_tree1(int x,int y);
void ve_tree2(int x,int y);

void box();

void vedat();
void dat(int i);
void taomatdat();

void menu();


