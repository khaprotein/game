/*


*/
#include<iostream>
#include"Do hoa.h"
#include"game.h"

using namespace std;

int main(){
	
	ShowCur(0);
	while(true){
	   GAME();
	}
	return 0;
}
